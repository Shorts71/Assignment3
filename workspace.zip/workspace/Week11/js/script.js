
const $ = selector => document.querySelector(selector);

const joinList = evt => {                 // Event object
    if ($("#email_1").value == "") { 
        // notify user of error
        alert("Email is required.");
        $("#email_error").textContent ="Email is required";
        // don't allow form to be submitted
        evt.preventDefault();  
        $("first_name").value ="dhjdskdh";
    } 
};
$("DOMContentLoaded", () => {
    $("#join_list").addEventListener("click", joinList);
});
