const numbers=[];

for(let i =0; i<10; i++)
{
    numbers[i] =i+1;
}

let sum =0;
for(var i =0; i< numbers.length;i++){
    sum +=numbers[i];
}
document.write(sum);

